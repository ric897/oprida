from django.shortcuts import redirect, render
from django.template import base
from twilio.rest import Client
from .forms import *
from .models import *
from django.views.generic.list import ListView
from django.views.generic.edit import FormView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView
from django.contrib.auth import login
from urllib.parse import urlencode
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse
from django.contrib.auth.views import LoginView
from django.http import HttpResponse, HttpResponseRedirect
from rest_framework.viewsets import ModelViewSet
from django.core.mail import send_mail
import stripe
from django.template.loader import render_to_string
from django.db.models import Q
import lyricsgenius
from django.http import JsonResponse
import requests



# Create your views here.


def index(request):
    context = {}
    context['cases'] = Case.objects.all()



    return render(request, 'index.html', context)

def lyrics(request):
    print('here')
    newsearch = request.GET.get('search_term')
    print(newsearch)
    token = 'l3mw75zleD0i8vPFDPBYFG7lVaF1sIfKN1sH-0tEsPv6ADeAgWMZ0otly5sTRXJO'
    genius = lyricsgenius.Genius(token)
    # api_key = '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'
    # endpoint = "https://api.openai.com/v1/completions"
    # prompt = f"The following is a search term passed as a url parameter it represents a song and an artist , characters have been used to replace spaces and special character. Do you best to format the search term with its original chracter. Respond with just the search term. {newsearch}"
    # headers = {
    #     "Content-Type": "application/json",
    #     "Authorization": f"Bearer {api_key}"
    # }
    # data = {
    #     "model": "text-davinci-003",
    #     "prompt": prompt,
    #     "max_tokens": 50,
    #     "n": 1,
    #     "stop": None,
    #     "temperature": 0.5
    # }
    # response = requests.post(endpoint, headers=headers, json=data)
    # response_json = response.json()
    # print(response.json)
    # if response.status_code == 200:
    #     generated_text = response_json["choices"][0]["text"].strip()
    #     songsearch = generated_text
    #     print(songsearch)
    
    print('HERE 2')
    dict = genius.search(newsearch, per_page=1)
    song = dict['hits'][0]['result']['id']
    result = genius.song(song)

    return JsonResponse(result)

from django.http import FileResponse

def serve_file(request):
    file_path = '/Users/richardbuehling/Desktop/oprida/gigify/static/openapi.yaml'
    return FileResponse(open(file_path, 'rb'))


def plugin_manifest(request):
    data = {
        "schema_version": "v1",
        "name_for_human": "Genius Lyrics",
        "name_for_model": "lyrics",
        "description_for_human": "Get details on a song.",
        "description_for_model": "Get interesting details from a song. You will be receiving a large JSON object with various data on a song from the endpoint /lyrics/```search_term``` where search_term is the song requested by the user. It is passed as an argument.",
        "auth": {
            "type": "none"
        },
        "api": {
            "type": "openapi",
            "url": "https://oprida.com/openapi.yaml"
        },
        "logo_url": "https://your-domain.com/logo.png",
        "contact_email": "support@your-domain.com",
        "legal_info_url": "https://www.your-domain.com/legal"
    }
    return JsonResponse(data)


def approach(request):
    context = {}
    return render(request, 'approach.html', context)

def startups(request):
    context = {}
    return render(request, 'startups.html', context)

def enterprises(request):
    context = {}
    return render(request, 'enterprise.html', context)

def contact(request):
    context = {}
    return render(request, 'contact.html', context)

def generalapproach(request):
    context = {}
    return render(request, 'generalapproach.html', context)

class CaseList(ListView):
    model = Case
    template_name = 'casestudies.html'

class CaseDetail(DetailView):
    model = Case
    template_name = 'casedetail.html'

